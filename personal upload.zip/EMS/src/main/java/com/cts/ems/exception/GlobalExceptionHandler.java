package com.cts.ems.exception;

import java.time.LocalDateTime;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cts.ems.model.ErrorInfo;

import jakarta.servlet.http.HttpServletRequest;
@RestControllerAdvice 
public class GlobalExceptionHandler {
	
	
	
	@ExceptionHandler(AttendeeException.class)
	public ErrorInfo AttendeeExceptionHandler(AttendeeException e,HttpServletRequest url) {
		return new ErrorInfo(e.getMessage(),LocalDateTime.now(),url.getRequestURI());
	}
	
	
	@ExceptionHandler(UserException.class)
	public ErrorInfo UserExceptionHandler(UserException e,HttpServletRequest url) {
		return new ErrorInfo(e.getMessage(),LocalDateTime.now(),url.getRequestURI());
	}
	
	@ExceptionHandler(OrganizerException.class)
	public ErrorInfo OrganizerExceptionHandler(UserException e,HttpServletRequest url) {
		return new ErrorInfo(e.getMessage(),LocalDateTime.now(),url.getRequestURI());
	}
}



