package com.cts.ems.exception;

public class OrganizerException extends Exception{
	public OrganizerException(String msg) {
		super(msg);
	}
}
