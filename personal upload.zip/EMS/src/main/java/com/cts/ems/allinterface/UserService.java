package com.cts.ems.allinterface;

import java.util.List;

import com.cts.ems.dto.AttendeeUserDto;
import com.cts.ems.dto.LoginUserDto;
import com.cts.ems.dto.OrganizerUserDto;
import com.cts.ems.dto.PaymentUserDto;
import com.cts.ems.dto.UseruserDto;
import com.cts.ems.entity.Organizer;
import com.cts.ems.entity.User;
import com.cts.ems.exception.OrganizerException;
import com.cts.ems.exception.UserException;

public interface UserService {
	
	
	
	public User addUser (UseruserDto user);
	public UseruserDto getUser (String id) throws UserException;
	public User updateUser(String id,User user) throws UserException;
	public UseruserDto deleteUser(String userId) throws UserException;
	public Organizer addOrganizer(String orgId);
	public OrganizerUserDto getOrganizerById(String orgId) throws OrganizerException;
	public String deleteOrganizerById(String id) throws OrganizerException;
	public  AttendeeUserDto getAttendeeById(String id);
	public List<PaymentUserDto> getAllPayments(String organizerId ,String eventId) throws OrganizerException;
	public User forgotPassword(String userName,String email,String number,String newPassword) throws UserException;
	public User updateName(String id,String name) throws UserException;
	public User updateEmail(String id,String email) throws UserException;
	public User updateContactNumber(String id,String number) throws UserException;
	public User updateAge(String id,int age) throws UserException;
	public User updateGender(String id,String gender) throws UserException;
	public User updatePassword(String id, String Password) throws UserException;
	public User login(LoginUserDto login) throws UserException;

}
