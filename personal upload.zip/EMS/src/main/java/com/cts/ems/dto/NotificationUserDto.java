package com.cts.ems.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationUserDto {
	 private String message;
	private LocalDateTime sentTimeStamp;
	private String event_id;

}
