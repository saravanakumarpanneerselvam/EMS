package com.cts.ems.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.ems.entity.Organizer;

public interface OrganizerRepository extends JpaRepository<Organizer, String> {
	

}
