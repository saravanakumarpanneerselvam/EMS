package com.cts.ems.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

import org.apache.commons.lang3.RandomStringUtils;

@Entity
@Table(name="ticket")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Ticket{

    @Id
    private String ticketId;
    
    @SuppressWarnings("deprecation")
	@PrePersist
    public void generatedId() {
    	if(ticketId == null) {
    		ticketId=RandomStringUtils.randomAlphanumeric(3);
    		ticketId+=RandomStringUtils.randomNumeric(2);
    	}
    }

    @NotNull(message = "Booking date is required")
    private LocalDate bookingDate;

    @NotNull(message = "Status is required")
    private String status;

//    @NotNull(message = "Price is required")
//    private Double price;

    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "payment_id",nullable = false)
    @JsonIgnore
    private Payment payment;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "event_id",nullable = false)
    @JsonBackReference
    private Event event;



    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "attendee_id",nullable = false)
    @JsonBackReference
    private Attendee attendee;
}