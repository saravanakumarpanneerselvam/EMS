package com.cts.ems.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.ems.allinterface.UserService;
import com.cts.ems.dto.AttendeeUserDto;
import com.cts.ems.dto.EventUserDto;
import com.cts.ems.dto.FeedbackUserDto;
import com.cts.ems.dto.LoginUserDto;
import com.cts.ems.dto.NotificationUserDto;
import com.cts.ems.dto.OrganizerUserDto;
import com.cts.ems.dto.PaymentUserDto;
import com.cts.ems.dto.UseruserDto;
import com.cts.ems.entity.Attendee;
import com.cts.ems.entity.Event;
import com.cts.ems.entity.Feedback;
import com.cts.ems.entity.Notification;
import com.cts.ems.entity.Organizer;
import com.cts.ems.entity.Payment;
import com.cts.ems.entity.Ticket;
import com.cts.ems.entity.User;
import com.cts.ems.exception.AttendeeException;
import com.cts.ems.exception.OrganizerException;
import com.cts.ems.exception.UserException;
import com.cts.ems.repository.AttendeeRepository;
import com.cts.ems.repository.EventRepository;
import com.cts.ems.repository.OrganizerRepository;
import com.cts.ems.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImp implements UserService{
	
//--------------------Repository----------------------------------
	private final UserRepository userRepo;
	private final AttendeeRepository attendeeRepo;
	private final OrganizerRepository organizerRepo;
	private final EventRepository eventRepo;
	
//-----------------------User-----------------------------------
	
// sign up creating a user
	@Transactional
	public User addUser(UseruserDto userDto) {
		Attendee attendee=new Attendee();
		attendee.setAge(userDto.getAge());
		attendee.setContactNumber(userDto.getContactNumber());
		attendee.setName(userDto.getName());
		attendee.setEmail(userDto.getEmail());
		attendee.setPassword(userDto.getPassword());
		attendee.setGender(userDto.getGender());
		
		log.info("New User is created for name: "+userDto.getName());
		return attendeeRepo.save(attendee);
	}
	
// deleting the user
	public UseruserDto deleteUser(String userId) throws UserException {
	    Optional<User> userOpt = userRepo.findById(userId);
	    if (!userOpt.isPresent()) {
	    	log.error("An exception is thrown while deleting user with "+userId+" , thrown by deleteuser method.");
	        throw new UserException("No user exists with that ID");
	    }
	    User user = userOpt.get();
	    UseruserDto userDto = UseruserDto.builder()
	            .age(user.getAge())
	            .contactNumber(user.getContactNumber())
	            .email(user.getEmail())
	            .gender(user.getGender())
	            .name(user.getName())
	            .password(user.getPassword())
	            .build();
	    userRepo.deleteById(userId);
	    log.info("An user with user id : "+userId+" is deleted by deleteuser method.");
	    return userDto;
	}


//updating user by id and Entire User
	public User updateUser(String user_id,User user) throws UserException {
		log.info("Entering updateUser method with user_id: {}", user_id);
		Optional<User> useropt=userRepo.findById(user_id);
		if(!useropt.isPresent()) {
			log.error("No such account exists for user_id: "+ user_id);
			throw new UserException("No such account exist");
		}
		User u=useropt.get();
		log.debug("Updating user details for user_id: {}", user_id);
		u.setAge(user.getAge());
		u.setContactNumber(user.getContactNumber());
		u.setEmail(user.getEmail());
		u.setName(user.getName());
		u.setPassword(user.getPassword());
		u.setGender(user.getGender());
		log.info("User details updated successfully for user_id: {}", user_id);
		return userRepo.save(u);
	}
	
//get all User
	public List<UseruserDto> getAllUser() throws UserException{
		List<User> userList=userRepo.findAll();
		if(userList.isEmpty()) {
			log.error("User table does not contain any user");
			throw new UserException("User table does not contain any user");
		}
		List<UseruserDto> userDtoList=new ArrayList<>();
		log.debug("Getting all user....");
		for(User user : userList) {
			UseruserDto userDto=UseruserDto.builder()
					.age(user.getAge())
					.contactNumber(user.getContactNumber())
					.email(user.getEmail())
					.gender(user.getGender())
					.name(user.getName())
					.password(user.getPassword())
					.build();
			userDtoList.add(userDto);
		}
		log.info("All users returned successfully.");
		return userDtoList;
	}
	
	
//login using username and password
	public User login(LoginUserDto login) throws UserException {
		List<User> userList=userRepo.findAll();
		for(User user:userList) {
			if(user.getName().equals(login.getName()) && user.getPassword().equals(login.getPassword())) {
				log.info("Login successfullty");
				return user;
			}
		}
		log.error("No user exist for username and password");
		throw new UserException("User does not exist");
	}
	
	
	
//forgot password by using user fields
	public User forgotPassword(String userName,String email,String number,String newPassword)throws UserException {
		List<User> userList=userRepo.findAll();
		for(User user:userList) {
			if(user.getName().equals(userName) && user.getContactNumber().equals(number) && user.getEmail().equals(email)) {
				user.setPassword(newPassword);
				userRepo.save(user);
				log.info("Password changed successfully by forget password method");
				return user;
			}
		}
		log.error("No user exist to change password");
		throw new UserException("User does not exist");
	}
	
	
//view user by user id
	public UseruserDto getUser(String userId) throws UserException {
        log.info("Entering getUserDto method with userId: {}", userId);
		Optional<User> useropt=userRepo.findById(userId);
		if(useropt.isPresent()) {
			User user=useropt.get();
			UseruserDto userDto=UseruserDto.builder()
					.age(user.getAge())
					.contactNumber(user.getContactNumber())
					.email(user.getEmail())
					.gender(user.getGender())
					.name(user.getName())
					.password(user.getPassword())
					.build();
			log.info("UserDto created successfully for userId: {}", userId);
			return userDto;
		}

		log.error("User does not exist for userId: {}", userId);
		throw new UserException("User does not exist");
	}
	
	
//update userName by user id
	public User updateName(String id,String name) throws UserException{
		log.info("Entering updateUser method with id: {}", id);
		Optional<User> user=userRepo.findById(id);
		if(!user.isPresent()) {
			log.error("User does not exist for id: {}", id);
			throw new UserException("User does not exist");
		} 
		log.debug("Updating user name for id: {}", id);
		User user1=user.get();
		user1.setName(name);
		log.info("User name changed successfully for user id:  {}", id);
		return userRepo.save(user1);
	}
	
//update user email by using user id
	public User updateEmail(String id,String email) throws UserException{
		log.info("Entering updateEmail method with id: {}", id);
		Optional<User> user=userRepo.findById(id);
		if(!user.isPresent()) {
			log.error("User does not exist for id: {}", id);
			throw new UserException("User does not exist");
		}
		log.debug("Updating user email for id: {}", id);
		User user1=user.get();
		user1.setEmail(email);
		log.info("User email changed successfully for user id:  {}", id);
		return userRepo.save(user1);
	}
	
//update user contact number using user id
	public User updateContactNumber(String id,String number) throws UserException{
		Optional<User> user=userRepo.findById(id);
		log.info("Entering updateContactNumber method with id: {}", id);
		if(!user.isPresent()) {
			log.error("User does not exist for id: {}", id);
			throw new UserException("User does not exist");
		}
		log.debug("Updating user updateContactNumber for id: {}", id);
		User user1=user.get();
		user1.setContactNumber(number);
		log.info("User Contact Number changed successfully for user id:  {}", id);
		return userRepo.save(user1);
	}
	
//update user age by using user id
	public User updateAge(String id, int age) throws UserException {
	    log.info("Attempting to update age for user with id: {}", id);
	    Optional<User> user = userRepo.findById(id);
	    if (!user.isPresent()) {
	        log.error("User with id: {} does not exist", id);
	        throw new UserException("User does not exist");
	    }
	    User user1 = user.get();
	    user1.setAge(age);
	    User updatedUser = userRepo.save(user1);
	    log.info("Successfully updated age for user with id: {}", id);
	    
	    return updatedUser;
	}

	
//update user gender by using user id
	public User updateGender(String id, String gender) throws UserException {
	    log.info("Attempting to update gender for user with id: {}", id);
	    Optional<User> user = userRepo.findById(id);
	    if (!user.isPresent()) {
	        log.error("User with id: {} does not exist", id);
	        throw new UserException("User does not exist");
	    }
	    User user1 = user.get();	    
	    user1.setGender(gender);
	    User updatedUser = userRepo.save(user1);
	    log.info("Successfully updated gender for user with id: {}", id);
	    
	    return updatedUser;
	}

//update user password by using user id
	public User updatePassword(String id, String password) throws UserException {
	    log.info("Attempting to update password for user with id: {}", id);
	    Optional<User> user = userRepo.findById(id);
	    if (!user.isPresent()) {
	        log.error("User with id: {} does not exist", id);
	        throw new UserException("User does not exist");
	    }
	    User user1 = user.get();
	    user1.setPassword(password);
	    User updatedUser = userRepo.save(user1);
	    log.info("Successfully updated password for user with id: {}", id);
	    
	    return updatedUser;
	}

	
	
	
	
//--------------------------Attendee-----------------------------------------
	
	
	
//get Attendee by id 
	public AttendeeUserDto getAttendeeById(String id) throws AttendeeException {
	    log.info("Attempting to retrieve attendee with id: {}", id);
	    
	    if (!attendeeRepo.existsById(id)) {
	        log.error("Attendee with id: {} not found", id);
	        throw new AttendeeException("Attendee Not found");
	    }
	    Attendee attendee = attendeeRepo.findById(id).orElse(null);
	    if (attendee == null) {
	        log.error("Attendee with id: {} returned null after existence check", id);
	        return null;
	    }
	    log.debug("Attendee with id: {} found, processing feedbacks and notifications", id);
	    List<Feedback> feedList = attendee.getFeedbacks();
	    List<FeedbackUserDto> feedbackDtoList = new ArrayList<>();
	    for (Feedback feedback : feedList) {
	        FeedbackUserDto feedbackDto = FeedbackUserDto.builder()
	                .comment(feedback.getComment())
	                .event_id(feedback.getEvent().getEventId())
	                .rating(feedback.getRating())
	                .submittedTimestamp(feedback.getSubmittedTimestamp())
	                .feedbackId(feedback.getFeedbackId())
	                .build();
	        feedbackDtoList.add(feedbackDto);
	    }
	    List<Notification> notificationList = attendee.getNotifications();
	    List<NotificationUserDto> notificationDtoList = new ArrayList<>();
	    for (Notification notification : notificationList) {
	        NotificationUserDto notificationDto = NotificationUserDto.builder()
	                .event_id(notification.getEvent().getEventId())
	                .message(notification.getMessage())
	                .sentTimeStamp(notification.getSentTimeStamp())
	                .build();
	        notificationDtoList.add(notificationDto);
	    }
	    
	    AttendeeUserDto attendeeDto = AttendeeUserDto.builder()
	            .age(attendee.getAge())
	            .contactNumber(attendee.getContactNumber())
	            .userId(attendee.getUserId())
	            .name(attendee.getName())
	            .gender(attendee.getGender())
	            .email(attendee.getEmail())
	            .preferences(attendee.getPreferences())
	            .tickets(attendee.getTickets())
	            .feedbacks(feedbackDtoList)
	            .notifications(notificationDtoList)
	            .build();
	    log.info("Successfully retrieved and processed attendee with id: {}", id);
	    return attendeeDto;
	}

	
	
//get all attendee 
	public List<AttendeeUserDto> getAllAttendees() throws AttendeeException {
	    log.info("Attempting to retrieve all attendees");
	    
	    List<Attendee> attendees = attendeeRepo.findAll();
	    if (attendees.isEmpty()) {
	        log.error("Attendee table is empty");
	        throw new AttendeeException("Attendee table is empty");
	    }
	    
	    List<AttendeeUserDto> attendeeDtos = new ArrayList<>();
	    for (Attendee attendee1 : attendees) {
	        Attendee attendee = attendeeRepo.findById(attendee1.getUserId()).orElse(null);
	        if (attendee == null) {
	            log.error("Attendee with id: {} returned null after existence check", attendee1.getUserId());
	            continue;
	        }
	        
	        log.debug("Processing feedbacks and notifications for attendee with id: {}", attendee.getUserId());
	        
	        List<Feedback> feedList = attendee.getFeedbacks();
	        List<FeedbackUserDto> feedbackDtoList = new ArrayList<>();
	        for (Feedback feedback : feedList) {
	            FeedbackUserDto feedbackDto = FeedbackUserDto.builder()
	                    .comment(feedback.getComment())
	                    .event_id(feedback.getEvent().getEventId())
	                    .rating(feedback.getRating())
	                    .submittedTimestamp(feedback.getSubmittedTimestamp())
	                    .feedbackId(feedback.getFeedbackId())
	                    .build();
	            feedbackDtoList.add(feedbackDto);
	        }
	        
	        List<Notification> notificationList = attendee.getNotifications();
	        List<NotificationUserDto> notificationDtoList = new ArrayList<>();
	        for (Notification notification : notificationList) {
	            NotificationUserDto notificationDto = NotificationUserDto.builder()
	                    .event_id(notification.getEvent().getEventId())
	                    .message(notification.getMessage())
	                    .sentTimeStamp(notification.getSentTimeStamp())
	                    .build();
	            notificationDtoList.add(notificationDto);
	        }
	        
	        AttendeeUserDto attendeeDto = AttendeeUserDto.builder()
	                .age(attendee.getAge())
	                .contactNumber(attendee.getContactNumber())
	                .userId(attendee.getUserId())
	                .name(attendee.getName())
	                .gender(attendee.getGender())
	                .email(attendee.getEmail())
	                .preferences(attendee.getPreferences())
	                .tickets(attendee.getTickets())
	                .feedbacks(feedbackDtoList)
	                .notifications(notificationDtoList)
	                .build();
	        attendeeDtos.add(attendeeDto);
	    }
	    
	    log.info("Successfully retrieved and processed all attendees");
	    return attendeeDtos;
	}

	
	
// if you want to delete the attendee delete User
//if you want to update the attendee update user
	
	
	
//-----------------------------Organizer-----------------------------------------
	

//get Organizer by using organizer id
	public OrganizerUserDto getOrganizerById(String id) throws OrganizerException {
	    log.info("Attempting to retrieve organizer with id: {}", id);
	    
	    if (!organizerRepo.existsById(id)) {
	        log.error("No organizer exists with id: {}", id);
	        throw new OrganizerException("No organizer exists");
	    }
	    
	    Organizer organizer = organizerRepo.findById(id).orElse(null);
	    if (organizer == null) {
	        log.error("Organizer with id: {} returned null after existence check", id);
	        return null;
	    }
	    
	    log.debug("Organizer with id: {} found, processing user and events", id);
	    
	    User user = organizer.getUser();        
	    List<EventUserDto> eventDtoList = new ArrayList<>();
	    List<Event> events = organizer.getEventsOrganized();
	    for (Event event : events) {
	        EventUserDto eventDto = EventUserDto.builder()
	                .category(event.getCategory())
	                .eventId(event.getEventId())
	                .location(event.getLocation())
	                .name(event.getName())
	                .regDate(event.getRegDate())
	                .build();
	        eventDtoList.add(eventDto);   
	    }
	    
	    OrganizerUserDto organizerDto = OrganizerUserDto.builder()
	            .age(user.getAge())
	            .contactNumber(user.getContactNumber())
	            .email(user.getEmail())
	            .gender(user.getGender())
	            .name(user.getName())
	            .userId(user.getUserId())
	            .events(eventDtoList)
	            .build();
	    
	    log.info("Successfully retrieved and processed organizer with id: {}", id);
	    
	    return organizerDto;
	}

	//get All Organizer
	public List<OrganizerUserDto> getAllOrganizers() throws OrganizerException {
	    log.info("Attempting to retrieve all organizers");
	    
	    List<Organizer> organizers = organizerRepo.findAll();
	    if (organizers.isEmpty()) {
	        log.error("Organizer table is empty");
	        throw new OrganizerException("Organizer table is empty");
	    }
	    
	    List<OrganizerUserDto> organizerDtos = new ArrayList<>();
	    for (Organizer org : organizers) {
	        User user = org.getUser();
	        
	        log.debug("Processing events for organizer with id: {}", user.getUserId());
	        
	        List<EventUserDto> eventDtoList = new ArrayList<>();
	        List<Event> events = org.getEventsOrganized();
	        for (Event event : events) {
	            EventUserDto eventDto = EventUserDto.builder()
	                    .category(event.getCategory())
	                    .eventId(event.getEventId())
	                    .location(event.getLocation())
	                    .name(event.getName())
	                    .regDate(event.getRegDate())
	                    .build();
	            eventDtoList.add(eventDto);   
	        }
	        
	        OrganizerUserDto organizerDto = OrganizerUserDto.builder()
	                .age(user.getAge())
	                .contactNumber(user.getContactNumber())
	                .email(user.getEmail())
	                .gender(user.getGender())
	                .name(user.getName())
	                .userId(user.getUserId())
	                .events(eventDtoList)
	                .build();
	        organizerDtos.add(organizerDto);
	    }
	    
	    log.info("Successfully retrieved and processed all organizers");
	    
	    return organizerDtos;
	}

    
// delete Organizer by using Organizer Id
	public String deleteOrganizerById(String id) throws OrganizerException {
	    log.info("Attempting to delete organizer with id: {}", id);
	    
	    if (organizerRepo.existsById(id)) {
	        log.debug("Organizer with id: {} exists, proceeding with deletion", id);
	        
	        List<Event> events = eventRepo.findAll();
	        for (Event event : events) {
	            if (event.getOrganizer().getUserId().equals(id)) {
	                log.debug("Deleting event with id: {} organized by organizer with id: {}", event.getEventId(), id);
	                eventRepo.deleteById(event.getEventId());
	            }
	        }
	        
	        organizerRepo.deleteById(id);
	        log.info("Organizer with id: {} deleted successfully", id);
	        return "Organizer with ID " + id + " deleted successfully.";
	    }
	    
	    log.error("No organizer exists with id: {}", id);
	    throw new OrganizerException("No user exists");
	}

  
 
 // adding Organizer
    public Organizer addOrganizer(String id) {
    	Organizer organizer=new Organizer();
		User u=userRepo.findById(id).get();
		organizer.setUser(u);

		log.info("Successfully added organizer with user id: {}", id);
		return organizerRepo.save(organizer);
    }
    
 // get all payments by using organizer Id
    public List<PaymentUserDto> getAllPayments(String organizerId, String eventId) throws OrganizerException {
        log.info("Attempting to retrieve all payments for organizer with id: {} and event with id: {}", organizerId, eventId);
        
        if (!organizerRepo.existsById(organizerId)) {
            log.error("No organizer exists with id: {}", organizerId);
            throw new OrganizerException("No organizer exists");
        }
        
        List<Event> eventList = organizerRepo.findById(organizerId).get().getEventsOrganized();
        String event_id = "";
        List<Ticket> tickets = new ArrayList<>();
        for (Event event : eventList) {
            if (event.getEventId().equals(eventId)) {
                event_id = event.getEventId();
                tickets = event.getTickets();
                break;
            }
        }
        
        if (event_id.isEmpty()) {
            log.error("No event exists for the given organizer id: {} and event id: {}", organizerId, eventId);
            throw new OrganizerException("No event exists for the given organizer id");
        }
        
        log.debug("Found event with id: {} for organizer with id: {}, processing tickets", event_id, organizerId);
        
        List<PaymentUserDto> paymentDtoList = new ArrayList<>();
        for (Ticket ticket : tickets) {
            Payment payment = ticket.getPayment();
            PaymentUserDto paymentDto = PaymentUserDto.builder()
                    .amount(payment.getAmount())
                    .paymentDate(payment.getPaymentDate())
                    .paymentMethod(payment.getPaymentMethod())
                    .paymentId(payment.getPaymentId())
                    .paymentStatus(payment.getPaymentStatus())
                    .transactionId(payment.getTransactionId())
                    .build();
            paymentDtoList.add(paymentDto);
        }
        
        log.info("Successfully retrieved all payments for organizer with id: {} and event with id: {}", organizerId, eventId);
        
        return paymentDtoList;
    }
}


