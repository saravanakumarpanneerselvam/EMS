package com.cts.ems.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FeedbackUserDto {
	
    private String feedbackId;
    private int rating;
    private String comment;
    private LocalDateTime submittedTimestamp;
    private String event_id;

}
