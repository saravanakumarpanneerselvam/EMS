package com.cts.ems.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.ems.entity.Attendee;
import com.cts.ems.entity.User;

public interface AttendeeRepository extends JpaRepository<Attendee, String> {


	
}
