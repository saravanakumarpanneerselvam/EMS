package com.cts.ems.entity;



import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import jakarta.persistence.JoinColumn;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="attendees")
@Data
@NoArgsConstructor
@AllArgsConstructor
@PrimaryKeyJoinColumn(name="attendee_id")
public class Attendee extends User {
   

    @Column(name="membership_status")
    private Boolean membershipStatus = false;

    @ElementCollection
    @CollectionTable(name="attendee_preferences",joinColumns = @JoinColumn(name = "attendee_id"))
    @Column(name = "preference")
    private List<String> preferences;

    @OneToMany(mappedBy = "attendee",cascade = CascadeType.PERSIST,orphanRemoval = true)
    @JsonManagedReference
    private List<Ticket> tickets;

    @OneToMany(mappedBy = "attendee",cascade = CascadeType.PERSIST,orphanRemoval = true)
    @JsonManagedReference
    private List<Feedback> feedbacks;

    @OneToMany(mappedBy = "attendee",cascade = CascadeType.PERSIST,orphanRemoval = true)
    @JsonManagedReference
    private List<Notification> notifications;

}