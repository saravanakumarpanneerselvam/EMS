package com.cts.ems.controller;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ems.dto.AttendeeUserDto;
import com.cts.ems.dto.LoginUserDto;
import com.cts.ems.dto.OrganizerUserDto;
import com.cts.ems.dto.PaymentUserDto;
import com.cts.ems.dto.UseruserDto;
import com.cts.ems.entity.Organizer;
import com.cts.ems.entity.User;
import com.cts.ems.exception.AttendeeException;
import com.cts.ems.exception.OrganizerException;
import com.cts.ems.exception.UserException;
import com.cts.ems.service.UserServiceImp;



@RequestMapping("/user")
@RestController
public class UserController {
	
	@Autowired
	UserServiceImp uServ;
	
	
//------------------------User----------------------
	
	
//Creating User
	@PostMapping("/signup")
	public User signUp(@RequestBody UseruserDto userDto) {
		User attAdd=uServ.addUser(userDto);
		return attAdd;
	}
	
//Login using Username and password
	@GetMapping("/login")
	public ResponseEntity<User> login(@RequestParam String name,@RequestParam String password) throws UserException {
		LoginUserDto logins=new LoginUserDto();
		logins.setName(name);
		logins.setPassword(password);
		User user= uServ.login(logins);
		return ResponseEntity.ok(user);
	}
	
//Deleting User
	@DeleteMapping("/deleteaccount/{id}")
	public ResponseEntity<UseruserDto> deleteAccount(@PathVariable("id") String id) throws UserException {
	    UseruserDto userDto = uServ.deleteUser(id);
	    return ResponseEntity.ok(userDto);
	}

	
//get User By User id
	@GetMapping("/finduserbyid")
	public UseruserDto viewAccount(@RequestParam String id) throws UserException {
		return uServ.getUser(id);
	}
	
//Update User by User Body
	@PostMapping("/updateaccount")
	public User updateAccount(@RequestParam("user_id") String user_id,@RequestBody User user) throws UserException {
		return uServ.updateUser(user_id,user);
		
	}
	
//Forgot Password 
	@GetMapping("/forgotpassword")
	public User forgotPassword(@RequestParam String userName,@RequestParam String email,@RequestParam String number,@RequestParam String newPassword) throws UserException {
		return uServ.forgotPassword(userName, email, number, newPassword);
	}
	
//get All User
	@GetMapping("/getalluser")
	public List<UseruserDto> getAllUser() throws UserException{
		return uServ.getAllUser();
	}
	
//update UserName using User Id
	@PutMapping("/updateusername/{id}/{name}")
	public User updateUserName(@PathVariable("id") String id,@PathVariable("name") String name) throws UserException {
		return uServ.updateName(id, name);
	}
	
//update User Email by using User Id
	@PutMapping("/updateemail/{id}/{email}")
	public User updateUserEmail(@PathVariable("id") String id,@PathVariable("email") String email) throws UserException {
		return uServ.updateEmail(id, email);
	}
	
//update User Contact Number by using User Id
	@PutMapping("/updatenumber/{id}/{number}")
	public User updateUserContactNumber(@PathVariable("id") String id,@PathVariable("number") String number) throws UserException {
		return uServ.updateContactNumber(id, number);
	}
	
//update User age by using User Id
	@PutMapping("/updateage/{id}/{age}")
	public User updateUserAge(@PathVariable("id") String id,@PathVariable("age") Integer age) throws UserException {
		return uServ.updateAge(id, age);
	}
	
//update User gender by using User Id
	@PutMapping("/updategender/{id}/{gender}")
	public User updateUserGender(@PathVariable("id") String id,@PathVariable("gender") String gender) throws UserException {
		return uServ.updateGender(id, gender);
	}


//-----------------------Attendee----------------------------------------
	
//get Attendee by using Attendee id
	@GetMapping("/getattendeebyid/{id}")
	public AttendeeUserDto getAttendeeById(@PathVariable("id") String id) {
		return uServ.getAttendeeById(id);
	}

//get all attendee	
	@GetMapping("/allattendees")
	public List<AttendeeUserDto> getAllAttendees() {
	    return uServ.getAllAttendees();
	}
	
//----------------------------Organizer-------------------------------------------
	
//get Organizer by using organizer id
	@GetMapping("/getorganizerbyid/{id}")
	public OrganizerUserDto getOrganizerById(@PathVariable("id") String id) throws OrganizerException {
	    return uServ.getOrganizerById(id);
	}
	
//get All Organizer
	@GetMapping("/getallorganizer")
	public List<OrganizerUserDto> getAllOrganizers() throws OrganizerException {
	    return uServ.getAllOrganizers();
	}
	
//delete Organizer by Organizer Id
	@DeleteMapping("/deleteorganizerbyid/{id}")
    public String deleteOrganizerById(@PathVariable("id") String id) throws OrganizerException {
        return uServ.deleteOrganizerById(id);
    }
	
//create organizer
	@PostMapping("/addorganizer/{id}")
	public Organizer addOrganizer(@PathVariable("id") String id) {
		return uServ.addOrganizer(id);
	}
	
//get all payment by organizer id
	@GetMapping("/getpaymentsbyorganizerid/{organizerId}/{eventId}")
	public List<PaymentUserDto> getAllPayments(@PathVariable("organizerId") String organizerId,@PathVariable("eventId") String eventId) throws OrganizerException{
		return uServ.getAllPayments(organizerId, eventId);
	}



}
