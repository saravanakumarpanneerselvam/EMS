package com.cts.ems.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

import org.apache.commons.lang3.RandomStringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "feedback")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Feedback {
    @Id
    private String feedbackId;
    
    @SuppressWarnings("deprecation")
	@PrePersist
    public void generatedId() {
    	if(feedbackId == null) {
    		feedbackId=RandomStringUtils.randomAlphanumeric(3);
    		feedbackId+=RandomStringUtils.randomNumeric(2);
    	}
    }

    @NotNull(message = "Rating is required")
    @Min(value=0)
    @Max(value=5,message = "Rating should be less than 5")
    private int rating;

    @NotNull(message = "Comment is Required")
    private String comment;

    @NotNull(message = "Submitted timestamp is Required")
    private LocalDateTime submittedTimestamp;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "event_id")
    @JsonIgnore
    private Event event;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "attendee_id")
    @JsonIgnore
    private Attendee attendee;

}