package com.cts.ems.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.ems.entity.Event;

public interface EventRepository extends JpaRepository<Event, String> {

}
