package com.cts.ems.model;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ErrorInfo {
	String errorMsg;
	LocalDateTime tStamp;
	String url;
	
}
