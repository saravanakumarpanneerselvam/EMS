package com.cts.ems.entity;

import org.apache.commons.lang3.RandomStringUtils;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Entity
@Table(name="users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Inheritance(strategy = InheritanceType.JOINED)
public class User {
    @Id
    private String userId;
    
    @SuppressWarnings("deprecation")
	@PrePersist
    public void generatedId() {
    	if(userId == null) {
    		userId=RandomStringUtils.randomAlphanumeric(3);
    		userId+=RandomStringUtils.randomNumeric(2);
    	}
    }

    @NotNull(message = "Name is required")
    private String name;

    @NotNull(message = "Email is required")
    @Email(message = "Please provide a valid email address")
    @Column(unique = true)
    private String email;

    @NotNull(message = "Password is required")
    private String password;

    @NotNull(message = "Contact number is required")
    @Pattern(regexp = "\\d{10}",message ="Contact number must be 10digits")
    private String contactNumber;


    @NotNull(message = "Age is Required")
    @Min(value = 12,message = "Age must be greater than 12")
    private Integer age;

    @NotNull(message = "Gender is required")
    @Column(length = 10)
    private String gender;
    
    @OneToOne(mappedBy = "user", cascade = CascadeType.REMOVE, orphanRemoval = true)
    @JsonBackReference
    private Organizer organizer;

}